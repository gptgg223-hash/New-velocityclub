from spotipy.oauth2 import SpotifyClientCredentials
import spotipy

sp = spotipy.Spotify(
    auth_manager=SpotifyClientCredentials(
        client_id="b427a821797445ea9e0b8c0b3d55f1ba",
        client_secret="71754cba3f824de4a7aabfda3b76f98a"
    )
)

results = sp.search(q="Believer", limit=5)

for track in results["tracks"]["items"]:
    print(track["name"])
